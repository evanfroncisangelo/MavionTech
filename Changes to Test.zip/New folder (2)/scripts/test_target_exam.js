// Run with: node --test scripts/test_target_exam.js
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { test } = require('node:test')
const vm = require('node:vm')
const { transformSync } = require('@babel/core')

function compile(relativePath) {
  const filename = path.join(__dirname, '..', relativePath)
  return transformSync(fs.readFileSync(filename, 'utf8'), {
    filename, configFile: false, babelrc: false,
    plugins: ['@babel/plugin-transform-modules-commonjs'],
  }).code
}
const targetCode = compile('utils\\targetExam.js')
const helperCode = compile('utils\\queryHelper.js')

function setup({ cachedTrack = 'IP', localTrack, remoteTrack = 'FE', remoteError, timeout = false } = {}) {
  const reads = [], writes = [], queries = [], logs = [], timeouts = []
  const helper = {}
  vm.runInNewContext(helperCode, {
    exports: helper,
    require: () => ({}),
    setTimeout, clearTimeout,
  })
  const query = {
    select(columns) { queries.push(['select', columns]); return query },
    eq(column, value) { queries.push(['eq', column, value]); return query },
    maybeSingle() {
      queries.push(['maybeSingle'])
      return timeout ? new Promise(() => {}) : Promise.resolve({
        data: remoteTrack ? { target_exam_level: remoteTrack } : null,
        error: remoteError,
      })
    },
  }
  const imports = {
    './supabase': { supabase: {
      from(table) { queries.push(['from', table]); return query },
      auth: { getSession: async () => ({ data: { session: { user: { id: 'signed-in-user' } } } }) },
    } },
    './cache': {
      getCache: async (key) => { reads.push(key); return cachedTrack },
      setCache: async (...args) => { writes.push(args) },
    },
    './database': {
      getActiveUserSession: async () => { reads.push('local-session'); return { target_exam_level: localTrack } },
      saveUserSession: async () => {},
    },
    './queryHelper': {
      writeOrQueue: async () => ({ success: true }),
      withTimeout(promise, milliseconds) {
        timeouts.push(milliseconds)
        // Exercise the real timeout implementation without waiting six seconds.
        return helper.withTimeout(promise, timeout ? 5 : milliseconds)
      },
    },
  }
  const exports = {}
  vm.runInNewContext(targetCode, {
    exports,
    require(name) { assert.ok(name in imports, `Unexpected import: ${name}`); return imports[name] },
    console: { warn: (...args) => logs.push(args) },
  })
  return { resolve: exports.resolveUserTargetExam, setTrack: exports.setUserTargetExamTrack, reads, writes, queries, logs, timeouts }
}

test('remote personal_info fetch uses imported timeout and updates both track caches', async () => {
  const app = setup()
  assert.equal(await app.resolve('user-id', 'IP'), 'FE')
  assert.deepEqual(app.timeouts, [6000])
  assert.deepEqual(app.queries, [
    ['from', 'personal_info'], ['select', 'target_exam_level'],
    ['eq', 'user_id', 'user-id'], ['maybeSingle'],
  ])
  assert.ok(app.writes.some(([key, track]) => key === 'user_target_exam' && track === 'FE'))
  assert.ok(app.writes.some(([key, track]) => key === 'library_target_exam' && track === 'FE'))
  assert.equal(app.logs.length, 0)
})

test('Library can reuse its batch-read track without a duplicate cache read', async () => {
  const app = setup({ remoteTrack: 'IP' })
  assert.equal(await app.resolve('user-id', 'FE', { cachedTrack: 'FE' }), 'IP')
  assert.equal(app.reads.length, 0)
  assert.deepEqual(app.timeouts, [6000])
})

test('an absent batch-read track still uses the local session without re-reading cache', async () => {
  const app = setup({ localTrack: 'Fundamental IT Engineer (FE)', remoteTrack: null })
  assert.equal(await app.resolve('user-id', 'IP', { cachedTrack: null }), 'FE')
  assert.deepEqual(app.reads, ['local-session'])
})

test('remote response errors are logged and preserve the saved track', async () => {
  const app = setup({ cachedTrack: 'FE', remoteError: { message: 'Unavailable' } })
  assert.equal(await app.resolve('user-id', 'IP'), 'FE')
  assert.equal(app.logs[0][0], 'Target exam refresh failed; keeping saved track:')
})

test('remote timeout preserves the cached track and reports the failure', async () => {
  const app = setup({ cachedTrack: 'FE', timeout: true })
  assert.equal(await app.resolve('user-id', 'IP'), 'FE')
  assert.deepEqual(app.timeouts, [6000])
  assert.equal(app.logs[0][1].message, 'Request timed out')
})

test('a newer in-app selection overrides the Library hydration snapshot while offline', async () => {
  const app = setup({ remoteError: { message: 'Network unavailable' } })
  await app.setTrack('FE', { id: 'user-id' })
  assert.equal(await app.resolve('user-id', 'IP', { cachedTrack: 'IP' }), 'FE')
  assert.equal(app.reads.length, 0)
})
