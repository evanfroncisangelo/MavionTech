// Run with: node --test scripts/test_library_loading.js
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { test } = require('node:test')
const vm = require('node:vm')
const { transformSync } = require('@babel/core')

const filename = path.join(__dirname, '..', 'screens', 'navigations', 'study', 'Library.js')
const { code } = transformSync(fs.readFileSync(filename, 'utf8'), {
  filename,
  configFile: false,
  babelrc: false,
  plugins: ['@babel/plugin-transform-modules-commonjs', '@babel/plugin-transform-react-jsx'],
})

const book = { id: 'book', title: 'Networks', subject: 'Technology', exam_level: 'IP', cover_image_url: 'cover', total_pages: 10 }
const video = { id: 'video', title: 'Networks lecture', subject: 'Technology', exam_level: 'IP', description: 'Searchable transcript' }
const flush = () => new Promise((resolve) => setImmediate(resolve))
function deferred() {
  let resolve, reject
  const promise = new Promise((res, rej) => { resolve = res; reject = rej })
  return { promise, resolve, reject }
}

function find(node, predicate) {
  if (!node || typeof node !== 'object') return undefined
  if (Array.isArray(node)) return node.map((child) => find(child, predicate)).find(Boolean)
  if (predicate(node)) return node
  return find(node.props?.children, predicate) || find(node.props?.refreshControl, predicate)
}

// Execute the real screen with deterministic hooks and deferred I/O, without a native runtime.
function mount({
  cache = {}, online = true, reading = deferred(), lectures = deferred(), track, session, progress,
  networkState = { isConnected: online, isInternetReachable: online },
  cacheRead, warmBeforeMount = false,
} = {}) {
  const states = [], effects = [], cleanups = [], calls = [], logs = [], cacheReads = [], trackCalls = []
  let cursor = 0, mounted = false, focus, tree, networkListener, networkUnsubscribed = false
  const react = {
    memo: (component) => component,
    useCallback: (callback) => callback,
    useRef(initial) {
      const index = cursor++
      if (!mounted) states[index] = { current: initial }
      return states[index]
    },
    useState(initial) {
      const index = cursor++
      if (!mounted) states[index] = initial
      return [states[index], (next) => {
        states[index] = typeof next === 'function' ? next(states[index]) : next
      }]
    },
    useEffect(effect) { if (!mounted) effects.push(effect) },
    createElement(type, props, ...children) { return { type, props: { ...props, children } } },
  }
  const native = Object.fromEntries([
    'Image', 'ScrollView', 'FlatList', 'Text', 'TouchableOpacity', 'View',
    'ActivityIndicator', 'TextInput', 'StatusBar', 'RefreshControl',
  ].map((name) => [name, name]))
  native.Image = Object.assign(() => {}, { prefetch: async () => {} })
  native.StyleSheet = { create: (styles) => styles }
  native.Platform = { OS: 'android' }
  const imports = {
    react,
    'react-native': native,
    '@react-native-community/netinfo': {
      addEventListener(listener) {
        networkListener = listener
        if (networkState) listener(networkState)
        return () => { networkUnsubscribed = true }
      },
      fetch() { assert.fail('Library must not wait for a connectivity fetch or server probe') },
    },
    'react-native-safe-area-context': { useSafeAreaInsets: () => ({ top: 0, bottom: 0 }) },
    '@expo/vector-icons': { Feather: 'Feather', Ionicons: 'Ionicons', MaterialCommunityIcons: 'MaterialCommunityIcons' },
    '../../../utils/supabase': { supabase: {
      auth: { getSession: () => session?.promise || Promise.resolve({ data: { session: { user: { id: 'user' } } } }) },
      from(table) {
        calls.push(table)
        const result = table === 'reading_materials' ? reading.promise
          : table === 'video_lectures' ? lectures.promise
          : progress?.promise || Promise.resolve({ data: [] })
        const query = { select: () => query, eq: () => query, order: () => query, then: (...args) => result.then(...args) }
        return query
      },
    } },
    '../../../utils/imageUrl': { resolveImageUrl: (url) => url },
    '../../../components/Skeleton': { SkeletonItem: 'SkeletonItem' },
    '../../../utils/cache': {
      getCache: () => assert.fail('Library must use the shared batch cache read'),
      getCacheMany: async (keys) => {
        cacheReads.push(keys)
        return cacheRead ? cacheRead.promise : { ...cache }
      },
      setCache: async (key, value) => { cache[key] = value },
    },
    '../../../utils/queryHelper': { withTimeout: (query) => Promise.resolve(query) },
    '../../../utils/responsiveLayout': { getScrollBottomPadding: () => 0 },
    '../../../utils/targetExam': { resolveUserTargetExam: (...args) => {
      trackCalls.push(args)
      return track?.promise || Promise.resolve(args[2]?.cachedTrack || 'IP')
    } },
    '../../../utils/offlineFiles': { precachePdfs: async () => {} },
  }
  const exports = {}
  vm.runInNewContext(code, {
    exports,
    require(name) {
      assert.ok(name in imports, `Unexpected screen import: ${name}`)
      return imports[name]
    },
    console: { warn: (...args) => logs.push(args), error: (...args) => logs.push(args) },
    setTimeout: () => 0,
  }, { filename })
  const navigation = { addListener: (_, listener) => { focus = listener; return () => {} } }
  function render() {
    cursor = 0
    tree = exports.default({ navigation })
    mounted = true
    effects.splice(0).forEach((effect) => {
      const cleanup = effect()
      if (typeof cleanup === 'function') cleanups.push(cleanup)
    })
    return tree
  }
  if (warmBeforeMount) exports.warmLibraryCache()
  render()
  return {
    reading, lectures, calls, logs, cache, cacheReads, trackCalls, render,
    warmCache: () => exports.warmLibraryCache(),
    remount() {
      cleanups.splice(0).forEach((cleanup) => cleanup())
      mounted = false
      return render()
    },
    updateNetwork: (state) => networkListener(state),
    unmount() {
      cleanups.forEach((cleanup) => cleanup())
      assert.equal(networkUnsubscribed, true)
    },
    focus: () => focus(),
    refresh: () => find(render(), (node) => node.type === 'RefreshControl').props.onRefresh(),
    hasBook: () => !!find(render(), (node) => node.props?.item?.id === 'book'),
    isLoading: () => !!find(render(), (node) => node.type?.name === 'LibrarySkeleton'),
    switchToVideos: () => find(render(), (node) => node.props?.accessibilityLabel === 'Open Video Lectures').props.onPress(),
    search: (text) => find(render(), (node) => node.type === 'TextInput').props.onChangeText(text),
    videoList: () => find(render(), (node) => node.type === 'FlatList')?.props.data,
    retry() {
      const button = find(render(), (node) => node.type === 'TouchableOpacity'
        && !!find(node.props.children, (child) => child.type === 'Text' && child.props.children.includes('Retry')))
      assert.ok(button, 'Expected visible Retry action')
      return button.props.onPress()
    },
  }
}

test('books appear before pending videos, authentication, and track; refresh waits for videos', async () => {
  const session = deferred(), track = deferred()
  const app = mount({ session, track })
  let refreshed = false
  const refresh = app.refresh().then(() => { refreshed = true })
  await flush()
  app.reading.resolve({ data: [book] })
  await flush()
  assert.equal(app.hasBook(), true)
  assert.equal(app.isLoading(), false)
  assert.equal(refreshed, false)
  app.switchToVideos()
  assert.equal(app.isLoading(), true)
  app.lectures.resolve({ data: [video] })
  await refresh
  assert.equal(app.isLoading(), false)
  assert.equal(app.videoList()[0].id, 'video')
})

test('videos appear while books are pending and description search is preserved', async () => {
  const app = mount()
  const refresh = app.refresh()
  app.lectures.resolve({ data: [video] })
  await flush()
  assert.equal(app.isLoading(), true)
  app.switchToVideos()
  assert.equal(app.isLoading(), false)
  app.search('transcript')
  assert.equal(app.videoList()[0].id, 'video')
  app.search('not present')
  assert.equal(app.videoList(), undefined)
  app.reading.resolve({ data: [book] })
  await refresh
})

test('offline refresh preserves saved books and saved videos', async () => {
  const app = mount({ online: false, cache: { library_materials: [book], library_videos: [video] } })
  await flush()
  assert.equal(app.hasBook(), true)
  await app.refresh()
  assert.equal(app.hasBook(), true)
  app.switchToVideos()
  assert.equal(app.videoList()[0].id, 'video')
  assert.equal(app.calls.length, 0)
})

test('unknown initial connectivity does not delay queries or wait for authentication', async () => {
  const session = deferred()
  const app = mount({ session, networkState: null })
  const refresh = app.refresh()
  await flush()
  assert.equal(app.calls.includes('reading_materials'), true)
  assert.equal(app.calls.includes('video_lectures'), true)
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  assert.equal(app.hasBook(), true)
  app.unmount()
})

test('an unreliable reachability verdict does not block working Supabase requests', async () => {
  const app = mount({ networkState: { isConnected: true, isInternetReachable: false } })
  const refresh = app.refresh()
  await flush()
  assert.equal(app.calls.includes('reading_materials'), true)
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  assert.equal(app.hasBook(), true)
  assert.equal(app.logs.length, 0)
})

test('connectivity changes are honored by existing focus and refresh handlers', async () => {
  const app = mount({ online: false, cache: { library_materials: [book], library_videos: [video] } })
  await flush()
  app.updateNetwork({ isConnected: true, isInternetReachable: null })
  const refresh = app.refresh()
  await flush()
  assert.equal(app.calls.includes('reading_materials'), true)
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  const requestCount = app.calls.length
  app.updateNetwork({ isConnected: false, isInternetReachable: false })
  await app.refresh()
  assert.equal(app.calls.length, requestCount)
  assert.equal(app.hasBook(), true)
})

test('an authentication failure cannot prevent the shelves from loading', async () => {
  const session = deferred()
  const app = mount({ session })
  const refresh = app.refresh()
  session.reject(new Error('Session unavailable'))
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  await flush()
  assert.equal(app.hasBook(), true)
  assert.equal(app.calls.includes('user_reading_progress'), false)
  assert.equal(app.logs.some(([message]) => message === 'Library track load error:'), true)
})

test('one batch hydrates books, videos and the saved user track', async () => {
  const app = mount({ cache: {
    library_materials: [book], library_videos: [video], user_target_exam: 'FE', library_target_exam: 'IP',
  } })
  await flush()
  assert.equal(app.isLoading(), false)
  assert.equal(app.cacheReads.length, 1)
  assert.equal(app.cacheReads[0].length, 4)
  assert.equal(app.trackCalls[0][2].cachedTrack, 'FE')
  assert.ok(find(app.render(), (node) => node.type === 'Text' && node.props.children.includes('FE Subject A')))
})

test('warm-up, mount, focus, refresh and remount share one completed hydration', async () => {
  const cacheRead = deferred(), track = deferred()
  const app = mount({ cacheRead, track, warmBeforeMount: true })
  app.focus()
  const refresh = app.refresh()
  assert.equal(app.cacheReads.length, 1)
  cacheRead.resolve({ library_materials: [book], library_videos: [video], user_target_exam: 'IP' })
  await flush()
  assert.equal(app.hasBook(), true)
  assert.equal(app.trackCalls.length, 1)
  assert.equal(app.trackCalls[0][2].cachedTrack, 'IP')
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  await app.warmCache()
  app.remount()
  assert.equal(app.hasBook(), true)
  assert.equal(app.isLoading(), false)
  await flush()
  assert.equal(app.cacheReads.length, 1)
})

test('even an empty saved shelf is batch-read only once', async () => {
  const app = mount({ online: false, warmBeforeMount: true })
  await flush()
  await app.refresh()
  app.remount()
  await app.refresh()
  assert.equal(app.cacheReads.length, 1)
})

test('cache read failures are logged and can be retried', async () => {
  const cacheRead = deferred()
  const app = mount({ cacheRead })
  cacheRead.reject(new Error('Disk unavailable'))
  await flush()
  assert.equal(app.logs.some(([message]) => message === 'Library cache load error:'), true)
  cacheRead.promise = Promise.resolve({ library_materials: [book], user_target_exam: 'IP' })
  await app.warmCache()
  app.remount()
  assert.equal(app.hasBook(), true)
  assert.equal(app.cacheReads.length, 2)
})

test('late disk hydration cannot replace newly refreshed books or videos', async () => {
  const cacheRead = deferred()
  const app = mount({ cacheRead })
  app.focus()
  const refresh = app.refresh()
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  cacheRead.resolve({
    library_materials: [{ ...book, id: 'old-book' }],
    library_videos: [{ ...video, id: 'old-video' }],
  })
  await flush()
  assert.equal(app.hasBook(), true)
  app.switchToVideos()
  assert.equal(app.videoList()[0].id, 'video')
})

test('late disk hydration cannot resurrect books removed by a successful empty refresh', async () => {
  const cacheRead = deferred()
  const app = mount({ cacheRead })
  const refresh = app.refresh()
  app.reading.resolve({ data: [] })
  app.lectures.resolve({ data: [video] })
  await refresh
  cacheRead.resolve({ library_materials: [book] })
  await flush()
  assert.equal(app.hasBook(), false)
  assert.equal(app.isLoading(), false)
})

test('a remote target update changes the track after the shelf has already rendered', async () => {
  const track = deferred()
  const app = mount({ track })
  const refresh = app.refresh()
  app.reading.resolve({ data: [book] })
  app.lectures.resolve({ data: [video] })
  await refresh
  assert.equal(app.hasBook(), true)
  track.resolve('FE')
  await flush()
  assert.ok(find(app.render(), (node) => node.type === 'Text' && node.props.children.includes('FE Subject A')))
  assert.equal(app.cacheReads.length, 1)
})

test('Supabase response errors preserve saved shelves and expose Retry', async () => {
  const app = mount({ cache: { library_materials: [book], library_videos: [video] } })
  await flush()
  const refresh = app.refresh()
  app.reading.resolve({ data: null, error: { message: 'Unavailable' } })
  app.lectures.resolve({ data: null, error: { message: 'Unavailable' } })
  await refresh
  assert.equal(app.hasBook(), true)
  assert.equal(app.cache.library_materials[0].id, 'book')
  const retry = app.retry()
  await retry
  assert.equal(app.logs.some(([message]) => message === 'Library load error:'), true)
  assert.equal(app.logs.some(([message]) => message.startsWith('Library video load error')), true)
  app.switchToVideos()
  assert.equal(app.videoList()[0].id, 'video')
})

test('reading rejection shows Retry immediately and can retry while videos remain pending', async () => {
  const app = mount()
  const refresh = app.refresh()
  app.reading.reject(new Error('Request timed out'))
  await flush()
  assert.equal(app.isLoading(), false)
  assert.equal(app.calls.filter((table) => table === 'reading_materials').length, 1)
  app.reading.promise = Promise.resolve({ data: [book] })
  const retry = app.retry()
  await flush()
  assert.equal(app.hasBook(), true)
  assert.equal(app.calls.filter((table) => table === 'video_lectures').length, 1)
  app.lectures.resolve({ data: [video] })
  await Promise.all([refresh, retry])
})

test('successful empty reading response replaces stale persistent data', async () => {
  const app = mount({ cache: { library_materials: [book] } })
  await flush()
  const refresh = app.refresh()
  app.reading.resolve({ data: [] })
  app.lectures.resolve({ data: [] })
  await refresh
  assert.equal(app.hasBook(), false)
  assert.equal(app.cache.library_materials.length, 0)
  assert.equal(app.logs.length, 0)
})

test('overlapping focus and refresh share requests; progress and known covers survive refresh', async () => {
  const progress = deferred()
  const app = mount({ progress, cache: { library_materials: [{ ...book, progress: 20 }] } })
  await flush()
  app.focus()
  const refresh = app.refresh()
  await flush()
  assert.equal(app.calls.filter((table) => table === 'reading_materials').length, 1)
  assert.equal(app.calls.filter((table) => table === 'video_lectures').length, 1)
  app.reading.resolve({ data: [{ ...book, cover_image_url: null }] })
  await flush()
  assert.equal(app.cache.library_materials[0].cover_image_url, 'cover')
  assert.equal(app.cache.library_materials[0].progress, 20)
  progress.resolve({ data: [{ reading_material_id: 'book', is_completed: true }] })
  await flush()
  assert.equal(app.cache.library_materials[0].progress, 100)
  app.lectures.resolve({ data: [video] })
  await refresh
})
