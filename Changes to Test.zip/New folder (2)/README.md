if mag testing kayo ibahin nyo lang  value ng initialRouteName sa App.js tapos mapupunta na sya sa screen na gusto nyo

Library and target-exam regressions: after `npm ci`, run
`node --test scripts/test_library_loading.js scripts/test_target_exam.js`.
Books and videos load independently; pull-to-refresh waits for both. Failed reading
requests keep saved books visible and expose Retry instead of silently retrying.
Session lookup runs in the background. Connectivity events skip requests only when
the device is disconnected; unknown reachability never blocks loading on a probe.
App warm-up, mount and refresh share one batch cache hydration. Target-exam
refreshes reuse its saved track and run with a timeout without delaying the shelf.